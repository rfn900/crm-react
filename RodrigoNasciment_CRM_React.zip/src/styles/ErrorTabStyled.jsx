import styled from "styled-components";

const ErrorTabStyled = styled.p`
  background: #f4f4f4;
  text-align: center;
  color: red;
  padding: 10px 0;
`;

export { ErrorTabStyled };
